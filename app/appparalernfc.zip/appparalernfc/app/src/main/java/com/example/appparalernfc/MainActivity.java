package com.example.appparalernfc;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.NfcA;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "NFC_DEBUG";

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter[] intentFiltersArray;
    private String[][] techListsArray;

    private TextView nfcContentTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialize o adaptador NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC não suportado neste dispositivo", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Inicialize o TextView
        nfcContentTextView = findViewById(R.id.nfcContentTextView);

        // Inicialize o PendingIntent
        pendingIntent = PendingIntent.getActivity(
                this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_MUTABLE
        );

        // Inicialize os filtros de intent
        IntentFilter techIntentFilter = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
        intentFiltersArray = new IntentFilter[]{techIntentFilter};

        // Defina as tecnologias que você deseja reconhecer
        techListsArray = new String[][]{
                new String[]{MifareClassic.class.getName()},
                new String[]{NfcA.class.getName()}
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume chamado");
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFiltersArray, techListsArray);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause chamado");
        nfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent chamado com ação: " + intent.getAction());

        if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            Log.d(TAG, "Intent ACTION_TECH_DISCOVERED recebido");
            processTechIntent(intent);
        } else {
            Log.d(TAG, "Ação de intent não tratada: " + intent.getAction());
        }
    }

    private void processTechIntent(Intent intent) {
        Log.d(TAG, "processTechIntent chamado");
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag == null) {
            Log.e(TAG, "Tag nula");
            return;
        }

        // Verifique se o tag suporta MifareClassic
        String[] techList = tag.getTechList();
        boolean isMifareClassic = false;
        for (String tech : techList) {
            if (tech.equals(MifareClassic.class.getName())) {
                isMifareClassic = true;
                break;
            }
        }

        if (isMifareClassic) {
            Log.d(TAG, "Tag é MifareClassic");
            MifareClassic mfc = MifareClassic.get(tag);
            try {
                mfc.connect();

                // Autenticar com a chave padrão para o setor correspondente ao bloco 4
                int sectorIndex = mfc.blockToSector(4);
                boolean authenticated = mfc.authenticateSectorWithKeyA(sectorIndex, MifareClassic.KEY_DEFAULT);
                if (authenticated) {
                    Log.d(TAG, "Autenticação bem-sucedida no setor " + sectorIndex);

                    // Ler o bloco 4
                    byte[] data = mfc.readBlock(4);

                    // Converter os bytes lidos em uma string usando a codificação ASCII
                    //Converte o array de bytes data em uma string, interpretando cada byte como um caractere ASCII.
                    String dataString = new String(data, Charset.forName("US-ASCII")).trim();
                    //Remove espaços em branco no início e no fim da string resultante.


                    // Exibir o conteúdo no TextView
                    nfcContentTextView.setText("Bloco 4: " + dataString);

                    // Registrar o conteúdo lido
                    Log.d(TAG, "Bloco 4 lido: " + dataString);
                } else {
                    Log.e(TAG, "Falha na autenticação no setor " + sectorIndex);
                    Toast.makeText(this, "Falha na autenticação do setor " + sectorIndex, Toast.LENGTH_SHORT).show();
                }
            } catch (IOException e) {
                Log.e(TAG, "Erro ao conectar ou ler o tag", e);
                Toast.makeText(this, "Erro ao ler o tag: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            } finally {
                try {
                    mfc.close();
                } catch (IOException e) {
                    Log.e(TAG, "Erro ao fechar conexão com o tag", e);
                }
            }
        } else {
            Log.d(TAG, "Tag não é MifareClassic");
            Toast.makeText(this, "Tag NFC não é do tipo Mifare Classic", Toast.LENGTH_SHORT).show();
        }
    }
}
